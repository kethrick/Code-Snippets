export const DECK_STORAGE_KEY = "mobileflashcards:flashcards"
export const NOTIFICATION_KEY = 'mobileflashcards:notifications'
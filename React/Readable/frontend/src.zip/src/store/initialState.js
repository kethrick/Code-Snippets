const initialState = {
    categories: [],
    posts: [],
    post: {},
    comments: []
}

export default initialState
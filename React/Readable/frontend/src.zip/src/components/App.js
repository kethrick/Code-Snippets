import React, { Component } from 'react'
import './App.css'

import CategoryList from './CategoryList/'

class App extends Component {
  render() {
    return (
      <div>
        <CategoryList />
      </div>
    )
  }
}

export default App

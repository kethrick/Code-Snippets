import React, { Component } from 'react'
import { connect } from 'react-redux'
import moment from 'moment'

import { fetchPostComments, deleteComment, postCommentVoteUpdate } from '../../actions/'

class CommentList extends Component{
    
    constructor(props, context) {
        super(props, context)
        this.state = {
            postId: this.props.postId,
            comments: this.props.comments,
        }
        this.handleCommentDelete = this.handleCommentDelete.bind(this)
        this.handleCommentVoteUp = this.handleCommentVoteUp.bind(this)
        this.handleCommentVoteDown = this.handleCommentVoteDown.bind(this)
    }

    componentDidMount() {
        this.props.fetchPostComments(this.props.postId)
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.comments !== nextProps.comments) {
            this.setState({comments: nextProps.comments})
        }
    }

    handleCommentDelete(event) {
        event.preventDefault()
        const commentId = event.target.parentNode.id
        let comment = this.state.comments.find(comment => comment.id === commentId)
        this.props.deleteComment(comment)
    }

    handleCommentVoteUp(event) {
        const commentId = event.target.parentNode.id
        let comment = this.state.comments.find(comment => comment.id === commentId)
        this.props.postCommentVoteUpdate(comment, 'upVote')
    }
    
    handleCommentVoteDown(event) {
        const commentId = event.target.parentNode.id
        let comment = this.state.comments.find(comment => comment.id === commentId)
        this.props.postCommentVoteUpdate(comment, 'downVote')
    }
    
    render (){
        return (
            <ul className='list-group list-group-flush'>
                {this.state.comments && this.state.comments.map(item => (
                    <li className='list-group-item' id={item.id} key={item.id}>
                        <p>
                            Author: {item.author} <br />
                            Created: {moment(item.timestamp).format('YYYY-MM-DD')}
                        </p>
                        <p>{item.body}</p>
                        <label>Vote Score:</label>&nbsp;
                        <button className="btn btn-default btn-xs" onClick={this.handleCommentVoteDown}>-</button>&nbsp;{item.voteScore}&nbsp;<button className="btn btn-default btn-xs" onClick={this.handleCommentVoteUp}>+</button>    
                        <br />
                        <button onClick={this.handleCommentDelete} className="btn btn-danger btn-md">Delete</button>
                    </li>
                ))}
            </ul>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    const postId = typeof ownProps.match !== 'undefined' && typeof ownProps.match.params !== 'undefined' ? ownProps.match.params.postId : ownProps.postId
    return {
        postId: postId,
        comments: typeof state.comments !== 'undefined' ? state.comments : [],
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        fetchPostComments: (postId) => dispatch(fetchPostComments(postId)),
        deleteComment: (comment) => dispatch(deleteComment(comment)),
        postCommentVoteUpdate: (comment, str) => dispatch(postCommentVoteUpdate(comment, str))
    }
}

export default connect(mapStateToProps, mapDispatchToProps) (CommentList)